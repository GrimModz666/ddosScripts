get your own ranges smh or use mine i legit could care less 

msg me on discord if your legit special and cant hit any ranges ill send you some i guess.

IF YOU WANT TO ZMAP RANGES

zmap -p21 -o old.txt
I ALREADY HAVE A VULN READY

pip install requests
pip show requests


ok simple python dreambox.py ytVuln.txt
(that was not writen by wolf on pc prolly some guy that made the loader)