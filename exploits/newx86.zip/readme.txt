its a new yarn exploit youll have to look for the ranges but if you have a good booter load the exploit.txt if not go find a new range
this was made by frostedflakes666
you black silly nigger coon
