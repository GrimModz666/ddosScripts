#pragma once

#include "includes.h"

BOOL killer_kill_by_port(port_t);
