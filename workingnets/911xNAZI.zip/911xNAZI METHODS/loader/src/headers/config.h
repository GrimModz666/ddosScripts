#pragma once

#define HTTP_SERVER "38.146.27.20"
#define HTTP_PORT 80

#define TFTP_SERVER "38.146.27.20"
