package main

import (
	"bufio"
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func Display(this *Admin, path string, username string) error {
	sleepDurations := map[string]time.Duration{
		"<<100>>":        100 * time.Millisecond,
		"<<200>>":        200 * time.Millisecond,
		"<<300>>":        300 * time.Millisecond,
		"<<400>>":        400 * time.Millisecond,
		"<<500>>":        500 * time.Millisecond,
		"<<600>>":        600 * time.Millisecond,
		"<<700>>":        700 * time.Millisecond,
		"<<800>>":        800 * time.Millisecond,
		"<<900>>":        900 * time.Millisecond,
		"<<1000>>":       1000 * time.Millisecond,
		"<<sleep(120)>>": 120 * time.Millisecond,
		"<<sleep(20)>>":  20 * time.Millisecond,
		"<<sleep(40)>>":  40 * time.Millisecond,
		"<<sleep(60)>>":  60 * time.Millisecond,
		"<<sleep(80)>>":  80 * time.Millisecond,
		"<<sleep(100)>>": 100 * time.Millisecond,
	}

	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer func(file *os.File) {
		err := file.Close()
		if err != nil {

		}
	}(file)

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)
	for scanner.Scan() {
		line := scanner.Text()
		for pattern, sleepDuration := range sleepDurations {
			if strings.Contains(line, pattern) {
				time.Sleep(sleepDuration)
				line = strings.ReplaceAll(line, pattern, "")
			}
		}
		var maxAttacksText string

		maxAtk, _ := database.GetMaxAttacks(username)
		totalAtk, _ := database.GetUserTotalAttacks(username)
		if maxAtk == 9999 {
			maxAttacksText = "∞"
		} else {
			maxAttacksText = strconv.Itoa(maxAtk)
		}
		ongoingAttacks, _ := database.Ongoing()
		line = strings.ReplaceAll(line, "<<$clear>>", "\033[2J\033[1H")
		_, err := this.conn.Write([]byte(fmt.Sprintf("%s\r\n", ReplaceFromMap(line, map[string]string{
			"\\x1b":             "\x1b",
			"\\u001b":           "\u001b",
			"\\033":             "\033",
			"\\r":               "\r",
			"\\n":               "\n",
			"\\a":               "\a",
			"\\b":               "\b",
			"\\t":               "\t",
			"\\v":               "\v",
			"\\f":               "\f",
			"\\007":             "\007",
			"<<$username>>":     username,
			"<<$botcount>>":     strconv.Itoa(clientList.Count()),
			"<<$ongoing>>":      strconv.Itoa(len(ongoingAttacks)),
			"<<$maxglobal>>":    strconv.Itoa(MaxGlobalSlots),
			"<<$totalattacks>>": strconv.Itoa(totalAtk),
			"<<$maxattacks>>":   maxAttacksText,
		}))))
		if err != nil {
			return err
		}
	}
	return nil
}

func DisplayTitle(this *Admin, username string) error {
	titlePath := "assets/branding/title.txt"
	data, err := os.ReadFile(titlePath)
	if err != nil {
		return err
	}

	title := string(data)

	var maxAttacksText string

	maxAtk, _ := database.GetMaxAttacks(username)
	totalAtk, _ := database.GetUserTotalAttacks(username)
	if maxAtk == 9999 {
		maxAttacksText = "∞"
	} else {
		maxAttacksText = strconv.Itoa(maxAtk)
	}
	ongoingAttacks, _ := database.Ongoing()

	title = ReplaceFromMap(title, map[string]string{
		"\\x1b":   "\x1b",
		"\\u001b": "\u001b",
		"\\033":   "\033",
		"\\r":     "\r",
		"\\n":     "\n",
		"\\a":     "\a",
		"\\b":     "\b",
		"\\t":     "\t",
		"\\v":     "\v",
		"\\f":     "\f",
		"\\007":   "\007",
		// user tfx
		"<<$user.username>>":     username,
		"<<$user.totalattacks>>": strconv.Itoa(totalAtk),
		"<<$user.maxattacks>>":   strconv.Itoa(maxAtk),

		// other tfx
		"<<$username>>":     username,
		"<<$botcount>>":     strconv.Itoa(clientList.Count()),
		"<<$ongoing>>":      strconv.Itoa(len(ongoingAttacks)),
		"<<$maxglobal>>":    strconv.Itoa(MaxGlobalSlots),
		"<<$totalattacks>>": strconv.Itoa(totalAtk),
		"<<$maxattacks>>":   maxAttacksText,
	})

	_, err = this.conn.Write([]byte(title))
	if err != nil {
		return err
	}

	return nil
}

func DisplayPrompt(username string) (string, error) {
	promptPath := "assets/branding/prompt.txt"
	data, err := os.ReadFile(promptPath)
	if err != nil {
		fmt.Println(err)
		return "", err
	}

	prompt := string(data)
	prompt = strings.ReplaceAll(prompt, "<<$username>>", username)
	prompt = strings.ReplaceAll(prompt, "\\x1b", "\x1b")
	prompt = strings.ReplaceAll(prompt, "\\033", "\033")

	return prompt, nil
}

func ReplaceFromMap(target string, objects map[string]string) string {
	for targetValue, value := range objects {
		target = strings.ReplaceAll(target, targetValue, value)
	}
	return target
}

func parseDuration(input string) (time.Duration, error) {
	var totalDuration time.Duration

	unitMultiplier := map[string]time.Duration{
		"d": time.Hour * 24,
		"h": time.Hour,
		"m": time.Minute,
		"s": time.Second,
	}

	regex := regexp.MustCompile(`(\d+)([dhms])`)
	matches := regex.FindAllStringSubmatch(input, -1)

	for _, match := range matches {
		value, err := strconv.Atoi(match[1])
		if err != nil {
			return 0, err
		}

		multiplier, exists := unitMultiplier[match[2]]
		if !exists {
			return 0, fmt.Errorf("unknown time unit in %s", match[0])
		}

		totalDuration += time.Duration(value) * multiplier
	}

	return totalDuration, nil
}
